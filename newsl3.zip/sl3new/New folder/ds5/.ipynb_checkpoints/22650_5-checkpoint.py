#!/usr/bin/env python
# coding: utf-8

# ## Lab Assignment 5
# 
# - 1. Implement logistic regression using Python/R to perform classification on Social_Network_Ads.csv
# dataset.
# - 2. Compute Confusion matrix to find TP, FP, TN, FN, Accuracy, Error rate, Precision, Recall on the given
# dataset.

# In[1]:


# Import necessary libraries
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score
import pandas as pd


# In[2]:


# Load the dataset
df = pd.read_csv("Social_Network_Ads.csv")

df.head()


# In[3]:


df.info() # View non-null count and dtype


# In[4]:


# Drop User ID
df.drop("User ID", axis=1, inplace=True)

#Encode Gender
df["Gender"] = df["Gender"].astype("category").cat.codes  # Male=1, Female=0

df.head()


# In[5]:


# Define features and target
X = df.drop("Purchased", axis=1)
y = df["Purchased"]

# Split into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardize features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

model = LogisticRegression()
model.fit(X_train, y_train)


# In[6]:


y_pred = model.predict(X_test)

# Compute confusion matrix
cm = confusion_matrix(y_test, y_pred)
tn, fp, fn, tp = cm.ravel()


# In[7]:


# Calculate metrics
accuracy = accuracy_score(y_test, y_pred)
error_rate = 1 - accuracy
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)

# Output results
metrics_dict = {
    "True Negatives (TN)": tn,
    "False Positives (FP)": fp,
    "False Negatives (FN)": fn,
    "True Positives (TP)": tp,
    "Accuracy": accuracy,
    "Error Rate": error_rate,
    "Precision": precision,
    "Recall": recall
}

for key, value in metrics_dict.items(): print(f"{key:<25}: {value}")


# In[8]:


import seaborn as sns
import matplotlib.pyplot as plt

# Plot confusion matrix
plt.figure(figsize=(6, 4))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=["Not Purchased", "Purchased"], 
            yticklabels=["Not Purchased", "Purchased"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()


# In[ ]:




