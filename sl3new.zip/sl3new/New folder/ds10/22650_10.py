import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

df = pd.read_csv("./Iris.csv")

print(df.head())
print(df.dtypes)

df.drop("Id", axis = 1, inplace = True)


# Create a histogram for each numeric feature
numeric_features = df.columns[:-1]

plt.figure(figsize=(10, 8))
for i, feature in enumerate(numeric_features):
    plt.subplot(2, 2, i + 1)
    sns.histplot(data=df, x=feature, bins=20, alpha=1.0)
    plt.title(f"Distribution of {feature}")
plt.tight_layout()
plt.show()

# Create boxplot for each feature
sns.set(style="whitegrid")
plt.figure(figsize=(12, 8))
for i, feature in enumerate(df.columns[:-1]):
    plt.subplot(2, 2, i+1)
    sns.boxplot(x=df[feature], data = df)
    plt.title(f"Boxplot of {feature}")
plt.tight_layout()
plt.show()


print(np.where(df["SepalWidthCm"] > 4.0))
print(np.where(df["SepalWidthCm"] <= 2.0))


print(df[df["SepalWidthCm"] > 4.0])
print(df[df["SepalWidthCm"] <= 2.0])





