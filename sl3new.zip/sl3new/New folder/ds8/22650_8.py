import seaborn as sns
import matplotlib.pyplot as plt

titanic = sns.load_dataset('titanic')
titanic.head()

sns.barplot(x="sex", y="age", hue="sex", data = titanic)


sns.catplot(x="sex", hue="survived", kind="count", data = titanic)


sns.histplot(data = titanic, x = "fare")


sns.histplot(data = titanic, x = "fare", binwidth = 30)
