import seaborn as sns
import matplotlib.pyplot as plt

titanic = sns.load_dataset('titanic')

print(titanic.head())


sns.barplot(x="sex", y="age", hue="sex", data = titanic)


sns.boxplot(x = "sex", y = "age", hue="sex", data = titanic)

sns.boxplot(x = "sex", y = "age", hue="survived", data = titanic)





